data:extend({
    {
        type = "bool-setting",
        name = "s6x-early-cliff",
        setting_type = "startup",
        default_value = false,
        order = "aa"
    },
})