local cliff = settings.startup["s6x-early-cliff"].value

if (cliff) then
	data.raw.technology["cliff-explosives"].prerequisites = {"explosives", "military-2"}
	data.raw.technology["cliff-explosives"].unit =
    {
		count = 200,
		ingredients =
		{
			{"automation-science-pack", 1},
			{"logistic-science-pack", 1}
		},
		time = 15
    }
	
	data.raw.recipe["cliff-explosives"].ingredients = {
		{type = "item", name = "explosives", amount = 10},
		{type = "item", name = "grenade", amount = 1},
		{type = "item", name = "barrel", amount = 1}
    }
end