local railtech = data.raw.technology["elevated-rail"]
railtech.prerequisites = { "railway", "concrete" }
railtech.unit.ingredients = { { "automation-science-pack", 1 }, { "logistic-science-pack", 1 } }